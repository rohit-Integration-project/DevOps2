# Docker-Commands-on-Webpage-and-predict-the-Salary
Run the Some Docker Commands on Webpage and predict the Salary
